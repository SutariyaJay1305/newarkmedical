from django.apps import AppConfig


class InPatientConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "in_patient"
